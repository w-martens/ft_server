service mysql start
service php7.3-fpm start
autoindex off
nginx -c /etc/nginx/nginx.conf -g 'daemon off;'

bash